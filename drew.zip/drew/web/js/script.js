function add_lot() {
// родительский элемент UL
const add_lot = document.getElementById('add');
// элемент для вставки перед ним (первый LI)
const first_lot = add_lot.getElementsByTagName('LI')[0];

// новый элемент
const new_lot = document.createElement('LI');
new_lot.innerHTML = 'Новый лот'

// вставка
add_lot.insertBefore(new_lot, first_lot)
}