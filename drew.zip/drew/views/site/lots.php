<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
/* @var $this yii\web\View */
/* @var $model app\models\Lot */
/* @var $form ActiveForm */
?>
<div class="lots">
    <?php $form = ActiveForm::begin(); ?>
    <ul>
        <?php
            $number = 1;
            $today = date("yy-m-d");
        ?>
        <table class="main_table">
            <tr>
                <td class="main_table_item"><? echo "Номер"?></td>
                <td class="main_table_item"><? echo "Название";?></td>
                <td class="main_table_item"><? echo "Владелец";?></td>
                <td class="main_table_item"><? echo "Описание" ;?></td>
                <td class="main_table_item"><? echo "Дедлайн" ;?></td>
                <td class="main_table_item"><? echo "Цена" ;?></td>
                <td class="main_table_item"><? echo "Покупатель" ;?></td>
                <td class="main_table_item"><? echo "Изменить цену" ;?></td>
            </tr>
            <?php foreach ($lots as $lot): {
                if($lot->Покупатель==Yii::$app->user->identity->username){
                    echo "Вы купили лот $lot->Название";
                    echo '  <br/>';
                }
                if($lot->Владелец==Yii::$app->user->identity->username){
                    echo "Вы продали $lot->Название";
                    echo '  <br/>';
                }
            } ?>
            <?php if($today<$lot->Дедлайн-1):{

            }?>
                <tr>
                        <td class="main_table_item"><? echo $number++?></td>
                        <td class="main_table_item"><? echo $lot->Владелец?></td>
                        <td class="main_table_item"><? echo $lot->Название?></td>
                        <td class="main_table_item"><? echo $lot->Описание?></td>
                        <td class="main_table_item"><? echo $lot->Дедлайн?></td>
                        <td class="main_table_item"><? echo $lot->Цена?></td>
                        <td class="main_table_item"><? echo $lot->Покупатель?></td>
                        <td class="main_table_item"><a href="http://drew/site/change_price?number_lot=<?php echo $number?>">*</a></td>
                </tr>
            <?php endif; ?>
        <?php endforeach; ?>
        </table>
    </ul>
    <?php ActiveForm::end(); ?>
    <style type="text/css">
        .main_table{
            text-align: center;

        }
        .main_table_item{
            padding: 8px;
            border: 1px solid black;
        }
    </style>
</div><!-- lots -->
