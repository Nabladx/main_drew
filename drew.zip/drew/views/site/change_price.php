<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Change_price */
/* @var $form ActiveForm */
?>
<div class="change_price">
    <?php $form = ActiveForm::begin(); ?>
    <?= $form->field($model, 'Новая_цена') ?>
        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>
</div><!-- change_price -->
