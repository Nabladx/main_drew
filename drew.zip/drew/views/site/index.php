<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
/* @var $this yii\web\View */

$this->title = 'Аукцион';
?>
<div class="site-index">

    <div class="jumbotron">
        <p class="lead1">Добро пожаловать в систему аукциона.</p>
        <p class="lead2">Слева Вам доступна информация по лотам.</p>
    </div>

    <div class="body-content">
        <div class="row">
            <div class="col-lg-4">
                <script src="/web/js/script.js"></script>

                <nav class="dws-menu">
                    <ul>
                        <li><a href="/site/lots"><i class="fa fa-home"></i>Инфо</a></li>
                        <li><a href="/site/lot"><i class="fa fa-shopping-cart"></i>Добавить</a></li>
                        <li><a href="/site/change_price"><i class="fa fa-shopping-cart"></i>Сгенерировать кошелек</a></li>
                    </ul>
                </nav>

            </div>
        </div>
    </div>
</div>
