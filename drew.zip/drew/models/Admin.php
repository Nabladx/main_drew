<?php
namespace app\models;
use Yii;
/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $username
 * @property string $password
 *
 * @property MyLots[] $myLots
 * @property Profiles[] $profiles
 */
class Admin extends \yii\db\ActiveRecord
{
 /**
  * {@inheritdoc}
  */
    public static function tableName()
    {
        return 'user';
    }
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'password'], 'required'],
            [['username', 'password'], 'string', 'max' => 255],
        ];
    }
    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'password' => 'Password',
        ];
    }
 /**
  * @return \yii\db\ActiveQuery
  *
  */
    public function getMyLots()
    {
        return $this->hasMany(MyLots::className(), ['user_id' => 'id']);
    }
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProfiles()
    {
        return $this->hasMany(Profiles::className(), ['user_id' => 'id']);
    }
}

