<?php
namespace app\models;
use Yii;
/**
 * This is the model class for table "my_lots".
 *
 * @property int $id
 * @property int $lot_id
 * @property string $username
 * @property string $Название
 * @property string $Описание
 * @property string $Дедлайн
 * @property int $Цена
 * @property string $Покупатель
 * @property int $user_id
 */
class MyLots extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'my_lots';
    }
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['lot_id', 'username', 'Название', 'Описание', 'Дедлайн', 'Цена',
                'Покупатель', 'user_id'], 'required'],
            [['lot_id', 'Цена', 'user_id'], 'integer'],
            [['Дедлайн'], 'safe'],
            [['username', 'Название', 'Описание', 'Покупатель'], 'string', 'max'
            => 255],
        ];
    }
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'lot_id' => 'Lot ID',
            'username' => 'Username',
            'Название' => 'Название',
            'Описание' => 'Описание',
            'Дедлайн' => 'Дедлайн',
            'Цена' => 'Цена',
            'Покупатель' => 'Покупатель',
            'user_id' => 'User ID',
        ];
    }
}
